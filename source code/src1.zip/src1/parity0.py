# Demonstrates modulo operator

x = int(input("What's x? "))

if x % 2 == 0:
    print("Even")
else:
    print("Odd")
