# Demonstrates a function with a positional argument and a named argument

name = input("What's your name? ")
print("hello, ", end="")
print(name)
