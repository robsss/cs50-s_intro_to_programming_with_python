# Demonstrates str functions

name = input("What's your name? ").strip().title()
print(f"hello, {name}")
