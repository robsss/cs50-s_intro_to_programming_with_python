# Demonstrates conversion from str to int

x = input("What's x? ")
y = input("What's y? ")

z = int(x) + int(y)

print(z)
