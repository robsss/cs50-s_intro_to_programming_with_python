# Demonstrates a function with a positional argument and a return value

name = input("What's your name? ")
print("hello,")
print(name)
