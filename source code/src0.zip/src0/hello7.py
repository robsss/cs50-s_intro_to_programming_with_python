# Demonstrates defining a function without parameters


def hello():
    print("hello")


name = input("What's your name? ")
hello()
print(name)
