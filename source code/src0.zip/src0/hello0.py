# Demonstrates a function with a positional argument

print("hello, world")
