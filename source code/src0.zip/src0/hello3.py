# Demonstrates a function with two positional arguments

name = input("What's your name? ")
print("hello,", name)
