# Demonstrates indexing into a list

students = ["Hermione", "Harry", "Rob"]

print(students[0])
print(students[1])
print(students[2])
