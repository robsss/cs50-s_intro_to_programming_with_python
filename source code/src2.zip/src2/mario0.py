# Prints a column of bricks

print("#")
print("#")
print("#")
