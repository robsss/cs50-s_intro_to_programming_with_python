# Demonstrates str multiplication

print("meow\n" * 3, end="")
