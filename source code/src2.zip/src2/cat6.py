# Demonstrates a for loop, using range

for i in range(3):
    print("meow")
