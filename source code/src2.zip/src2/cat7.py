# Demonstrates a for loop, with _ as a variable

for _ in range(3):
    print("meow")
