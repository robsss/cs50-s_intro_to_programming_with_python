# Prints row of coins using a function with str multiplication


def main():
    print_row(4)


def print_row(width):
    print("?" * width)


main()
