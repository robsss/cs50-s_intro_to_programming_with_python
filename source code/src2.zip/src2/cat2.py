# Demonstrates a while loop, counting up from 1

i = 1
while i <= 3:
    print("meow")
    i = i + 1
