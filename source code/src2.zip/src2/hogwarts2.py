# Demonstrates iterating over and indexing into a list

students = ["Hermione", "Harry", "Rob"]

for i in range(len(students)):
    print(i + 1, students[i])
