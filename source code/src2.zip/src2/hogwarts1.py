# Demonstrates iterating over a list

students = ["Hermione", "Harry", "Rob"]

for student in students:
    print(student)
