# Reads a CSV file into a list of dict objects, creating dict first

students = []

with open("students0.csv") as file:
    next(file)
    for line in file:
        name, house = line.rstrip().split(",")
        student = {"name": name, "house": house}
        students.append(student)

for student in students:
    print(f"{student['name']} is in {student['house']}")
