# Prints the type of a string

print(type("hello, world"))
