# Represents a student with multiple variables

name = input("Name: ")
house = input("House: ")
print(f"{name} from {house}")
