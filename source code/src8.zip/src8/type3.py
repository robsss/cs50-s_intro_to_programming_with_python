# Prints the type of a list

print(type(list()))
