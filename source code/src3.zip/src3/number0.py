# Gets a number from the user

x = int(input("What's x? "))
print(f"x is {x}")
