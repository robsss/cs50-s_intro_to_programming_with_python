# Demonstrates randint

import random

number = random.randint(1, 10)
print(number)
