# Demonstrates from

from random import choice

coin = choice(["heads", "tails"])
print(coin)
